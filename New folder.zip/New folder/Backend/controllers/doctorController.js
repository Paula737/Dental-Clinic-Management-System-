const User = require('../models/User');

// @desc Add new doctor
exports.addDoctor = async (req, res) => {
  const { name, email, password, specialization } = req.body;

  try {
    const doctorExists = await User.findOne({ email });
    if (doctorExists) return res.status(400).json({ message: 'Doctor already exists' });

    const doctor = await User.create({
      name,
      email,
      password,
      role: 'doctor',
      specialization
    });

    res.status(201).json({ message: 'Doctor added successfully', doctor });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @desc Get all doctors
exports.getDoctors = async (req, res) => {
  try {
    const doctors = await User.find({ role: 'doctor' }).select('-password');
    res.json(doctors);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @desc Delete a doctor
exports.deleteDoctor = async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: 'Doctor deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
