const Appointment = require('../models/Appointment');

exports.bookAppointment = async (req, res) => {
  const { doctorId, date } = req.body;
  try {
    const appointment = await Appointment.create({ //i have to wait until database finishes
      patient: null,
      doctor: doctorId,
      date
    });
    res.status(201).json(appointment);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getAppointments = async (req, res) => {
  try {
    const appointments = await Appointment.find()
      .populate('patient', 'name email')
      .populate('doctor', 'name email');
    res.json(appointments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
