const Feedback = require('../models/Feedback');

// @desc Add feedback
exports.addFeedback = async (req, res) => {
  const { doctorId, rating, comment } = req.body;

  try {
    const feedback = await Feedback.create({
      doctor: doctorId,
      rating,
      comment
    });

    res.status(201).json(feedback);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// @desc Get feedback for a doctor
exports.getDoctorFeedback = async (req, res) => {
  try {
    const feedbacks = await Feedback.find({ doctor: req.params.doctorId })
      .populate('patient', 'name email')
      .sort({ createdAt: -1 });

    res.json(feedbacks);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
