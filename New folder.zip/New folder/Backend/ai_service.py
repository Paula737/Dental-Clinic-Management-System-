import traceback
from flask import Flask, request, jsonify
import tensorflow as tf
from flask_cors import CORS
from PIL import Image
import numpy as np
import os

app = Flask(__name__)

# Enable CORS for all routes, all methods from Angular
CORS(app, resources={r"/*": {"origins": "http://localhost:4200"}})

# Define your categories (must match training)
CATEGORIES = ["CaS", "CoS", "Gum", "MC", "OC", "OLP", "OT"]

# Try to load model at startup
MODEL_PATH = "my_teeth_model.h5"
model = None
try:
    model = tf.keras.models.load_model(MODEL_PATH, compile=False)
    print(f"Model loaded successfully from {MODEL_PATH}")
except Exception as e:
    print(f"Error loading model from {MODEL_PATH}: {e}")


def preprocess_image(image_path):
    """Preprocess image for model prediction"""
    try:
        img = Image.open(image_path).convert("RGB")
        img = img.resize((256, 256))  # Must match model's expected input
        img_array = np.array(img) / 255.0
        img_array = np.expand_dims(img_array, axis=0)
        return img_array
    except Exception as e:
        print(f"Error preprocessing image: {e}")
        return None


@app.route('/predict', methods=['GET', 'POST'])
def upload():
    try:
        print("Request received. Files:", request.files)

        if 'image' not in request.files:
            return jsonify({"error": "No image file found"}), 400

        image_file = request.files['image']
        print(f"Processing file: {image_file.filename}")

        # Save to debug directory
        debug_dir = "debug_uploads"
        os.makedirs(debug_dir, exist_ok=True)
        debug_path = os.path.join(debug_dir, image_file.filename)
        image_file.save(debug_path)
        print(f"Saved debug image to {debug_path}")

        # Process image
        img_array = preprocess_image(debug_path)
        if img_array is None:
            return jsonify({"error": "Failed to preprocess image"}), 500

        # Ensure model is loaded
        if model is None:
            return jsonify({"error": "Model not loaded on server"}), 500

        # Prediction
        pred = model.predict(img_array)
        print(" Raw predictions:", pred)

        return jsonify({
            "disease": CATEGORIES[np.argmax(pred)],
            "confidence": f"{round(float(np.max(pred)), 4)*100}%"
        })

    except Exception as e:
        print(f"CRITICAL ERROR: {str(e)}", flush=True)
        return jsonify({
            "error": str(e),
            "type": type(e).__name__,
            "traceback": traceback.format_exc()
        }), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)
