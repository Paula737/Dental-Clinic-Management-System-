const express = require('express');
const { addFeedback, getDoctorFeedback } = require('../controllers/feedbackController');
const { protect } = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', addFeedback);
router.get('/:doctorId', getDoctorFeedback);

module.exports = router;