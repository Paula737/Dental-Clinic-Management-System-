const express = require('express');
const { addDoctor, getDoctors, deleteDoctor } = require('../controllers/doctorController');
const { protect, adminOnly } = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', protect, adminOnly, addDoctor);
router.get('/', getDoctors);// i removed protect so i can send data to fronend without token
router.delete('/:id', protect, adminOnly, deleteDoctor);

module.exports = router;
