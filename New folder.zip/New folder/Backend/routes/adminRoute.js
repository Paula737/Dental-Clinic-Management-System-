const express = require('express');
const router = express.Router();
const Doctor = require('../models/Doctor');
const Appointment = require('../models/Appointment');

// Get all doctors
router.get('/doctors', async (req, res) => {
    const doctors = await Doctor.find();
    res.json(doctors);
});

// Get all appointments
router.get('/appointments', async (req, res) => {
    const appointments = await Appointment.find().populate('doctor patient');
    res.json(appointments);
});

module.exports = router;
