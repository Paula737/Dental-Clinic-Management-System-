const express = require('express');
const multer = require('multer'); // i have to make uploads folder
const axios = require('axios');
const path = require('path');
const fs = require('fs');
const FormData = require('form-data'); 

const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

router.post('/upload', upload.single('image'), async (req, res) => {
  try {
    const formData = new FormData();
    formData.append('image', fs.createReadStream(req.file.path));

    const aiResponse = await axios.post('http://localhost:5001/predict', formData, {
      headers: formData.getHeaders()
    });

    res.json({
      success: true,
      analysis: aiResponse.data
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
