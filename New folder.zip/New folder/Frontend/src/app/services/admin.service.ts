// src/app/services/admin.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = 'http://localhost:5000/api'; // change to your backend URL

  constructor(private http: HttpClient) {}

  // Get all appointments
  getAppointments(): Observable<any> {
    return this.http.get(`${this.apiUrl}/appointments`);
  }

  // Get all doctors
  getDoctors(): Observable<any> {
    return this.http.get(`${this.apiUrl}/doctors`);
  }

  // Delete doctor by ID
  deleteDoctor(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/doctors/${id}`);
  }
}
