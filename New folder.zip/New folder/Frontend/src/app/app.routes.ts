import { Routes } from '@angular/router';

import { Home } from './home/home';
import { Login } from './auth/login/login';
import { Register } from './auth/register/register';
import { Dashboard } from './dashboard/dashboard';
import { Appointment } from './appointment/appointment';
import { Checkup } from './checkup/checkup';
import { Feedback } from './feedback/feedback';
import { AdminDashboardComponent} from './admin/dashboardadmin/dashboardadmin';

export const routes: Routes = [
  { path: '', component: Home },
  { path: 'login', component: Login },
  { path: 'register', component: Register },
  { path: 'dashboard', component: Dashboard },
  { path: 'appointment', component: Appointment },
  { path: 'checkup', component: Checkup },
  { path: 'feedback', component: Feedback },
  { path: 'admin', component: AdminDashboardComponent }

];
