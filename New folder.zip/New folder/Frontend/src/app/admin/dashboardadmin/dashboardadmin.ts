import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule],   // Add CommonModule here
  templateUrl: './dashboardadmin.html',
  styleUrls: ['./dashboardadmin.css']
})

export class AdminDashboardComponent implements OnInit {
  appointments: any[] = [];
  doctors: any[] = [];

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    // load initial doctors
    this.loadDoctors();
  }

  // Load appointments
  loadAppointments() {
    this.adminService.getAppointments().subscribe({
      next: (data) => this.appointments = data,
      error: (err) => console.error(err)
    });
  }

  // Load doctors
  loadDoctors() {
    this.adminService.getDoctors().subscribe({
      next: (data) => this.doctors = data,
      error: (err) => console.error(err)
    });
  }

  // Delete doctor
  removeDoctor(id: string) {
    this.adminService.deleteDoctor(id).subscribe({
      next: () => {
        this.loadDoctors(); // reload list after delete
      },
      error: (err) => console.error(err)
    });
  }
}
