import { Component, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-appointment',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './appointment.html',
  styleUrls: ['./appointment.css'],
})
export class Appointment implements OnInit {

  doctors = signal<any[]>([]);
    selectedDates: { [doctorId: string]: string } = {};
  message = '';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchDoctors();
  }

  fetchDoctors() {
    this.http.get<any[]>('http://localhost:5000/api/doctors').subscribe({
      next: (res) => {
        this.doctors.set(res);
        // console.log(this.doctors)
      },
      error: (err) => {
        console.error('Error loading doctors:', err);
      }
    });
  }

  bookAppointment(doctorId: string) {
    const date = this.selectedDates[doctorId];
    console.log('Clicked button', doctorId, 'with date', date);
    if (!date) {
      this.message = 'Please select a date';
      return;
    }

    this.http.post('http://localhost:5000/api/appointments', { doctorId, date }).subscribe({
      next: () => {
        this.message = 'Appointment booked!';
      },
      error: (err) => {
        console.error(err);
        this.message = 'API failed (maybe protected)';
      }
    });
  }
}
