import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-feedback',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './feedback.html',
  styleUrls: ['./feedback.css']
})
export class Feedback implements OnInit {
  doctors: any[] = [];
  selectedDoctorId: string = '';
  rating: number = 5;
  comment: string = '';
  message: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchDoctors();
  }

  fetchDoctors() {
    this.http.get('http://localhost:5000/api/doctors').subscribe((res: any) => {
      this.doctors = res;
    });
  }

  submitFeedback() {
    const data = {
      doctorId: this.selectedDoctorId,
      rating: this.rating,
      comment: this.comment
    };

    this.http.post('http://localhost:5000/api/feedback', data).subscribe({
      next: () => {
        this.message = 'Feedback submitted!';
        this.comment = '';
      },
      error: () => {
        this.message = 'Error submitting feedback.';
      }
    });
  }
}
