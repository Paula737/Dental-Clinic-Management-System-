import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, CommonModule,RouterModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class Register {
  name: string = '';
  email: string = '';
  password: string = '';
  confirmPassword: string = '';

  nameError: string = '';
  emailError: string = '';
  passwordError: string = '';
  confirmError: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  validateForm(): boolean {
    // reset
    this.nameError = '';
    this.emailError = '';
    this.passwordError = '';
    this.confirmError = '';

    if (!this.name.trim()) {
      this.nameError = 'Name is required.';
    }

    if (!this.email.toLowerCase().endsWith('@gmail.com')) {
      this.emailError = 'Must be a Gmail address (example@gmail.com).';
    }

    const digits = this.password.match(/\d/g) || [];
    if (this.password.length < 6 || digits.length < 2) {
      this.passwordError = 'Password must be at least 6 characters with at least 2 numbers.';
    }

    if (this.password !== this.confirmPassword) {
      this.confirmError = 'Passwords do not match.';
    }

    return !(this.nameError || this.emailError || this.passwordError || this.confirmError);
  }

  onSubmit() {
    if (!this.validateForm()) return;

    const user = { name: this.name, email: this.email, password: this.password };

    this.authService.register(user).subscribe({
      next: (res) => {
        alert('Registration successful!');
        this.router.navigate(['/login']);
      },
      error: () => {
        alert('Registration failed');
      }
    });
  }
}
