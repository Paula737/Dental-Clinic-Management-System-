import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class Login {
  email: string = '';
  password: string = '';
  emailError: string = '';
  passwordError: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  validateForm(): boolean {
    this.emailError = '';
    this.passwordError = '';

    // Email must end with @gmail.com
    const isGmail = this.email.toLowerCase().endsWith('@gmail.com');
    if (!isGmail) {
      this.emailError = 'Email must be a Gmail address (e.g. example@gmail.com).';
    }

    // Password must be at least 6 chars and contain at least 2 numbers
    const digitsMatch = this.password.match(/\d/g) || [];
    if (this.password.length < 6 || digitsMatch.length < 2) {
      this.passwordError = 'Password must be at least 6 characters and include at least 2 numbers.';
    }

    return !this.emailError && !this.passwordError;
  }

  onSubmit() {
    if (!this.validateForm()) {
      return; // stop submission
    }

    const userData = { email: this.email, password: this.password };
    this.authService.login(userData).subscribe({
      next: (res) => {
        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        alert('Login failed');
      }
    });
  }
}
