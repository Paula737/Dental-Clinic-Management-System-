import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-checkup',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './checkup.html',
  styleUrls: ['./checkup.css']
})
export class Checkup {
  selectedFile: File | null = null;
  previewUrl: string = '';
  result: any = null;
  info: any = null;
  diseaseInfo: any = {
  "CaS": {
    name: "Caries Susceptibility (Dental Caries)",
    description: "Refers to the tendency of teeth to develop dental caries (tooth decay). Caused by demineralization due to acids from bacteria.",
    prevention: "Use fluoride, improve oral hygiene, reduce sugar intake, apply sealants."
  },
  "CoS": {
    name: "Caries of Smooth Surfaces",
    description: "Dental caries occurring on the smooth flat surfaces of teeth. Often found between teeth or near gumline. Slower progression.",
    prevention: "Flossing, fluoride toothpaste, regular dental checkups."
  },
  "Gum": {
    name: "Gum Disease (Periodontal Disease)",
    description: "Includes gingivitis and periodontitis, causing swollen bleeding gums and potential tooth loss.",
    prevention: "Proper brushing, flossing, dental scaling, avoid smoking."
  },
  "MC": {
    name: "Mucocele",
    description: "Mucous cyst found inside the lips or mouth due to blocked salivary glands. Usually painless bluish swelling.",
    prevention: "Often heals by itself; persistent cases require surgical removal."
  },
  "OC": {
    name: "Oral Cancer",
    description: "Malignant growth in the oral cavity. Risk factors include tobacco/alcohol. Early detection is crucial.",
    prevention: "Avoid smoking & alcohol; regular dental exams."
  },
  "OLP": {
    name: "Oral Lichen Planus",
    description: "Chronic inflammatory condition with lace-like white patches or painful sores. Autoimmune in nature.",
    prevention: "Topical corticosteroids, good oral hygiene, stress control."
  },
  "OT": {
    name: "Oral Thrush (Oral Candidiasis)",
    description: "Fungal infection causing white creamy patches in the mouth. Common in weak immunity.",
    treatment: "Antifungal medication, oral hygiene."
  }
  };



  constructor(private http: HttpClient) {}

  onFileSelected(event: any) {
    const file = event.target.files[0];
    this.selectedFile = file;

    if (file) {
      const reader = new FileReader();
      reader.onload = e => this.previewUrl = (e.target as FileReader).result as string;
      reader.readAsDataURL(file);
    }
  }

  onUpload() {
    if (!this.selectedFile) {
      alert('Please select an image first!');
      return;
    }

    const formData = new FormData();
    formData.append('image', this.selectedFile);

    this.http.post('http://localhost:5001/predict', formData).subscribe({
      next: (res: any) => {
      this.result = res.analysis || res.disease || res;
      const code = this.result.disease || this.result; // adjust based on format
      this.info = this.diseaseInfo[code];
    },
      error: () => {
        alert('Error uploading image');
      }
    });
  }

}
